import React from 'react';
import { FunnelState, FunnelMetrics } from '../types';
import InlineInput from './InlineInput';
import { 
  Users, Mail, MousePointer, BookOpen, Crown, 
  DollarSign, TrendingUp, Zap, Power, ChevronRight 
} from 'lucide-react';

const StageToggle = ({ active, onChange }: { active: boolean, onChange: (v: boolean) => void }) => (
  <button 
    onClick={() => onChange(!active)}
    className={`p-2 rounded-xl transition-all ${active ? 'bg-white text-slate-800 shadow-lg scale-110' : 'bg-black/20 text-white/40 hover:bg-black/30'}`}
  >
    <Power size={14} strokeWidth={3} />
  </button>
);

interface FunnelVisualProps {
  state: FunnelState;
  metrics: FunnelMetrics;
  onUpdate: (key: keyof FunnelState, value: any) => void;
}

const FunnelVisual: React.FC<FunnelVisualProps> = ({ state, metrics, onUpdate }) => {
  const isProfitable = metrics.profit > 0;

  const stages = [
    { 
      id: 'traffic', label: 'Ad Traffic', value: metrics.visitors, color: 'bg-blue-600', 
      icon: <Users size={16} />, show: true,
      inputs: [
        { label: 'Spend', prefix: '$', key: 'budget' },
        { label: 'CPC', prefix: '$', key: 'cpc' }
      ]
    },
    { 
      id: 'leads', label: 'Offer Leads', value: metrics.leads, color: 'bg-indigo-600', 
      icon: <Mail size={16} />, 
      rate: metrics.visitors > 0 ? Math.round((metrics.leads / metrics.visitors) * 100) : 0,
      show: state.hasLeads,
      toggle: <StageToggle active={state.hasLeads} onChange={(v) => onUpdate('hasLeads', v)} />,
      inputs: [{ label: 'Opt-in', suffix: '%', key: 'optInRate' }]
    },
    { 
      id: 'salespage', label: 'Sales Page', value: metrics.linkClicks, color: 'bg-violet-600', 
      icon: <MousePointer size={16} />, 
      rate: metrics.showLeads ? (metrics.leads > 0 ? Math.round((metrics.linkClicks / metrics.leads) * 100) : 0) : (metrics.visitors > 0 ? Math.round((metrics.linkClicks / metrics.visitors) * 100) : 0),
      show: state.hasSalesPage,
      toggle: <StageToggle active={state.hasSalesPage} onChange={(v) => onUpdate('hasSalesPage', v)} />,
      inputs: [{ label: 'CTR', suffix: '%', key: 'clickThroughRate' }]
    },
    { 
      id: 'customers', label: 'Customers', value: metrics.completedOrders, color: 'bg-purple-700', 
      icon: <BookOpen size={16} />, 
      rate: metrics.showSalesPage ? (metrics.linkClicks > 0 ? Math.round((metrics.completedOrders / metrics.linkClicks) * 100) : 0) : (metrics.showLeads ? (metrics.leads > 0 ? Math.round((metrics.completedOrders / metrics.leads) * 100) : 0) : Math.round((metrics.completedOrders / metrics.visitors) * 100)),
      show: true,
      inputs: [
        { label: 'Conv', suffix: '%', key: 'salesConvRate' },
        { label: 'Price', prefix: '$', key: 'productPrice' }
      ]
    },
    { 
      id: 'upsell', label: 'Upsell Bundle', value: metrics.upsells, color: 'bg-amber-500', 
      icon: <Crown size={16} />, 
      rate: metrics.completedOrders > 0 ? Math.round((metrics.upsells / metrics.completedOrders) * 100) : 0,
      show: state.hasUpsell,
      toggle: <StageToggle active={state.hasUpsell} onChange={(v) => onUpdate('hasUpsell', v)} />,
      inputs: [
        { label: 'Take', suffix: '%', key: 'upsellRate' },
        { label: 'Price', prefix: '$', key: 'upsellPrice' }
      ]
    },
  ];

  return (
    <div className="w-full flex flex-col items-center">
      <div className="w-full flex flex-col gap-2.5 items-center">
        {stages.map((stage, idx) => {
          const currentWidth = 100 - (idx * 10);
          const isDeactivated = !stage.show && (stage.id === 'leads' || stage.id === 'salespage' || stage.id === 'upsell');
          
          if (!stage.show && !['leads', 'salespage', 'upsell'].includes(stage.id)) return null;

          return (
            <div 
              key={stage.id}
              className={`funnel-trap relative flex flex-col items-center justify-center transition-all duration-500 shadow-lg border-t border-white/10 py-6 sm:py-8
                ${isDeactivated ? 'opacity-20 scale-95 brightness-50 bg-slate-300 h-14' : `${stage.color} text-white`}
              `}
              style={{ width: `${Math.max(currentWidth, 65)}%` }}
            >
              <div className="flex items-center justify-between w-full max-w-[94%] sm:max-w-[85%] relative z-10 px-2 sm:px-4">
                <div className="w-10 flex justify-start">{stage.toggle}</div>
                <div className="flex flex-col items-center flex-1 px-2">
                  <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap justify-center">
                    <span className="text-2xl sm:text-3xl md:text-5xl font-black tracking-tighter drop-shadow-2xl leading-none">
                      {stage.value.toLocaleString()}
                    </span>
                    {stage.rate !== undefined && stage.show && (
                      <div className="bg-black/20 backdrop-blur-md px-1.5 py-0.5 rounded-lg border border-white/10 flex items-center shrink-0">
                        <span className="text-[9px] sm:text-[10px] font-black">{stage.rate}%</span>
                      </div>
                    )}
                  </div>
                  <div className="flex items-center gap-1 mt-1 text-white/70 uppercase tracking-widest font-black text-[8px] sm:text-[9px] whitespace-nowrap">
                    {stage.icon}
                    <span>{stage.label}</span>
                  </div>
                </div>
                <div className="w-20 sm:w-28 flex flex-col gap-1.5 items-end shrink-0">
                  {stage.show && stage.inputs.map((input: any) => (
                    <InlineInput 
                      key={input.key}
                      label={input.label}
                      prefix={input.prefix}
                      suffix={input.suffix}
                      value={(state as any)[input.key]}
                      onChange={(v: any) => onUpdate(input.key as keyof FunnelState, v)}
                    />
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-10 w-full flex flex-col items-center px-2">
        <div className={`w-full max-w-lg p-5 sm:p-6 rounded-[32px] border-2 transition-all flex flex-col sm:flex-row items-center justify-between shadow-xl relative overflow-hidden gap-6
          ${state.hasMaximizer ? 'bg-white border-emerald-100 ring-8 ring-emerald-50' : 'bg-slate-100 border-slate-200 opacity-60'}`}>
          <div className="flex items-center gap-4 w-full sm:w-auto">
            <StageToggle active={state.hasMaximizer} onChange={(v) => onUpdate('hasMaximizer', v)} />
            <div className="flex flex-col">
              <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">Recurring MRR</span>
              <span className={`text-sm font-bold ${state.hasMaximizer ? 'text-slate-800' : 'text-slate-400'}`}>Continuity Maximizer</span>
            </div>
          </div>
          <div className="flex items-center gap-6 justify-between w-full sm:w-auto sm:justify-end">
            {state.hasMaximizer ? (
              <>
                <div className="flex gap-2">
                  <InlineInput label="Take %" suffix="%" value={state.maximizerRate} onChange={(v: any) => onUpdate('maximizerRate', v)} isDark={true} />
                  <InlineInput label="Price $" prefix="$" value={state.maximizerPrice} onChange={(v: any) => onUpdate('maximizerPrice', v)} isDark={true} />
                </div>
                <div className="flex flex-col items-end min-w-[70px]">
                  <span className="text-xl font-black text-emerald-600 tracking-tighter">${metrics.mrr.toLocaleString()}</span>
                  <span className="text-[8px] font-bold text-slate-400 uppercase">MRR</span>
                </div>
              </>
            ) : (
              <span className="text-xs font-bold text-slate-400 italic">Maximize profit with continuity</span>
            )}
          </div>
        </div>
      </div>

      <div className="mt-8 flex flex-row gap-3 sm:gap-4 items-stretch justify-center w-full px-2 max-w-2xl">
        <div className="bg-emerald-500 border border-emerald-400/50 rounded-2xl p-3 sm:p-4 flex flex-col items-center justify-center text-white shadow-md flex-1 relative overflow-hidden transition-transform hover:scale-[1.02]">
          <span className="text-[8px] sm:text-[9px] font-black uppercase text-white/70 tracking-widest mb-1 leading-none">Gross Sales</span>
          <span className="text-lg sm:text-2xl font-black tracking-tighter leading-none">${Math.round(metrics.revenue).toLocaleString()}</span>
          <div className="absolute -bottom-1 -right-1 opacity-10 rotate-12"><DollarSign size={32} /></div>
        </div>
        <div className={`${isProfitable ? 'bg-slate-900 border-slate-800' : 'bg-rose-900 border-rose-800'} border rounded-2xl p-3 sm:p-4 flex flex-col items-center justify-center text-white shadow-md flex-1 relative overflow-hidden transition-transform hover:scale-[1.02]`}>
          <span className="text-[8px] sm:text-[9px] font-black uppercase text-white/40 tracking-widest mb-1 leading-none">Net Profit</span>
          <span className={`text-lg sm:text-2xl font-black tracking-tighter leading-none ${isProfitable ? 'text-emerald-400' : 'text-rose-400'}`}>
            ${Math.round(metrics.profit).toLocaleString()}
          </span>
          <div className={`absolute -bottom-1 -right-1 opacity-10 rotate-12 ${isProfitable ? 'text-emerald-400' : 'text-rose-400'}`}><TrendingUp size={32} /></div>
        </div>
      </div>

      <style>{`
        .funnel-trap { clip-path: polygon(0% 0%, 100% 0%, 88% 100%, 12% 100%); }
        @media (max-width: 480px) {
          .funnel-trap { clip-path: none; border-radius: 16px; width: 100% !important; margin-bottom: 8px; }
        }
      `}</style>
    </div>
  );
};

export default FunnelVisual;