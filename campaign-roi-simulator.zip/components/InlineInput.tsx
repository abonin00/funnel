import React, { useState, useEffect } from 'react';

interface InlineInputProps {
  value: number;
  onChange: (value: number) => void;
  prefix?: string;
  suffix?: string;
  label?: string;
  className?: string;
  isDark?: boolean;
}

const InlineInput: React.FC<InlineInputProps> = ({ 
  value, 
  onChange, 
  prefix, 
  suffix, 
  label, 
  className = "", 
  isDark = false 
}) => {
  const [innerValue, setInnerValue] = useState<string>(value.toString());
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    if (!isFocused && parseFloat(innerValue) !== value) {
      setInnerValue(value.toString());
    }
  }, [value, isFocused]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVal = e.target.value;
    setInnerValue(newVal);
    const parsed = parseFloat(newVal);
    if (!isNaN(parsed)) {
      onChange(parsed);
    } else if (newVal === '') {
      onChange(0);
    }
  };

  return (
    <div className={`flex flex-col items-center group/input ${className}`}>
      {label && (
        <span className={`text-[8px] font-black uppercase tracking-widest mb-1 whitespace-nowrap transition-opacity
          ${isDark ? 'text-slate-400' : 'text-white opacity-50'}`}>
          {label}
        </span>
      )}
      <div className={`flex items-center rounded-lg px-1.5 py-0.5 transition-all border 
        ${isDark 
          ? 'bg-slate-100 border-slate-200 focus-within:bg-slate-200 focus-within:border-slate-300' 
          : 'bg-white/10 hover:bg-white/20 focus-within:bg-white/30 border-white/20'}`}>
        {prefix && (
          <span className={`text-[9px] font-black mr-0.5 opacity-60 
            ${isDark ? 'text-slate-600' : 'text-white'}`}>
            {prefix}
          </span>
        )}
        <input
          type="number"
          value={innerValue}
          onChange={handleChange}
          onFocus={() => setIsFocused(true)}
          onBlur={() => {
            setIsFocused(false);
            setInnerValue(value.toString());
          }}
          className={`bg-transparent border-none p-0 text-[11px] font-black w-12 text-center focus:ring-0 
            ${isDark ? 'text-slate-800' : 'text-white'}`}
        />
        {suffix && (
          <span className={`text-[9px] font-black ml-0.5 opacity-60 
            ${isDark ? 'text-slate-600' : 'text-white'}`}>
            {suffix}
          </span>
        )}
      </div>
    </div>
  );
};

export default InlineInput;