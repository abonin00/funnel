
import React, { useState, useEffect } from 'react';
import { HelpCircle } from 'lucide-react';

interface InputFieldProps {
  label: string;
  value: number;
  onChange: (value: number) => void;
  step?: number;
  icon?: string;
  tooltip?: string;
}

const InputField: React.FC<InputFieldProps> = ({ label, value, onChange, step = 1, icon, tooltip }) => {
  // Use a local string state to allow for empty inputs and smoother decimal typing
  const [innerValue, setInnerValue] = useState<string>(value.toString());

  // Keep local state in sync with external value changes (e.g., resets)
  useEffect(() => {
    // Only update if the parsed value is different to avoid cursor jumps
    if (parseFloat(innerValue) !== value) {
      setInnerValue(value.toString());
    }
  }, [value]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newValue = e.target.value;
    setInnerValue(newValue);

    const parsed = parseFloat(newValue);
    if (!isNaN(parsed)) {
      onChange(parsed);
    } else if (newValue === '') {
      onChange(0);
    }
  };

  return (
    <div className="space-y-1.5 group">
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-slate-600 flex items-center gap-1.5">
          {label}
          {tooltip && (
            <div className="relative group/tip">
              <HelpCircle size={14} className="text-slate-400 cursor-help" />
              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 w-48 p-2 bg-slate-800 text-white text-[10px] rounded shadow-xl opacity-0 group-hover/tip:opacity-100 pointer-events-none transition-opacity z-50">
                {tooltip}
              </div>
            </div>
          )}
        </label>
      </div>
      <div className="relative">
        <input
          type="number"
          step={step}
          value={innerValue}
          onChange={handleChange}
          onBlur={() => setInnerValue(value.toString())} // Clean up formatting on blur
          className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2.5 px-4 text-slate-800 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all font-semibold"
        />
        {icon && (
          <span className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm select-none">
            {icon}
          </span>
        )}
      </div>
    </div>
  );
};

export default InputField;
