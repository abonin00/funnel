
import React from 'react';
import { FunnelMetrics } from '../types';
import { TrendingUp, GraduationCap, Wallet, Percent } from 'lucide-react';

interface ResultsBarProps {
  metrics: FunnelMetrics;
  invested: number;
  // Added missing funnelName prop to resolve type error in App.tsx
  funnelName: string;
}

const ResultsBar: React.FC<ResultsBarProps> = ({ metrics, invested, funnelName }) => {
  return (
    <div className="bg-slate-50/50 border-t border-slate-100 p-4 sm:p-6">
      <div className="w-full">
        {/* Metric Grid - Compact version for GHL widgets */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          <ResultItem 
            label="Customers" 
            value={metrics.completedOrders} 
            icon={<GraduationCap className="text-violet-500" size={14} />} 
          />
          <ResultItem 
            label="ROI" 
            value={`${metrics.roi}%`} 
            icon={<TrendingUp className="text-emerald-500" size={14} />} 
          />
          <ResultItem 
            label="Margin" 
            value={`${metrics.profitMargin}%`} 
            icon={<Percent className="text-amber-500" size={14} />} 
          />
          <ResultItem 
            label="Ad Spend" 
            value={`$${invested.toLocaleString()}`} 
            icon={<Wallet className="text-slate-500" size={14} />} 
          />
        </div>
      </div>
    </div>
  );
};

const ResultItem: React.FC<{ label: string; value: string | number; icon: React.ReactNode }> = ({ label, value, icon }) => (
  <div className="flex items-center gap-2 bg-white p-3 rounded-xl border border-slate-100 shadow-sm transition-transform hover:scale-[1.02]">
    <div className="p-1.5 rounded-lg bg-slate-50 border border-slate-100 shrink-0">
       {icon}
    </div>
    <div className="flex flex-col min-w-0 overflow-hidden">
      <span className="text-[8px] font-bold text-slate-400 uppercase tracking-widest leading-none mb-1">{label}</span>
      <span className="text-sm font-black text-slate-800 truncate">{typeof value === 'number' ? value.toLocaleString() : value}</span>
    </div>
  </div>
);

export default ResultsBar;
